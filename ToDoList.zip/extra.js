let dayMonth = document.getElementById("date");
let time = document.getElementById("time");
const weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
const month = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

  let date = new Date();
  dayMonth.textContent = `${weekday[date.getDay()]}, ${month[date.getMonth()]} ${date.getDate()}`;
  date = new Date();
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12;
  minutes = minutes < 10 ? '0'+minutes : minutes;
  time.textContent = hours + ':' + minutes + ' ' + ampm + ' ';

setInterval(function () {
    date = new Date();
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;
    minutes = minutes < 10 ? '0'+minutes : minutes;
    time.textContent = hours + ':' + minutes + ' ' + ampm + ' ';
}, 5000);
