const addBtn = document.querySelectorAll('#add-Btn');
const inputText = document.querySelectorAll('#input-Text');
const ulList = document.querySelectorAll('#unordered-List');
let myIU =[];
let myCheckedIU = [];
let myInotU =[];
let myCheckedInotU = [];
let mynotIU =[];
let myCheckednotIU = [];
let mynotInotU =[];
let myCheckednotInotU = [];

function getArrayAsStrings(i) {
  if(i == 0) {
    return "myIU";
  }
  if(i == 1) {
    return "myInotU";
  }
  if(i == 2) {
    return "mynotIU";
  }
  else {
    return "mynotInotU";
  }
}

function getArrayCheckedAsStrings(i) {
  if(i == 0) {
    return "myCheckedIU";
  }
  if(i == 1) {
    return "myCheckedInotU";
  }
  if(i == 2) {
    return "myCheckednotIU";
  }
  else {
    return "myCheckednotInotU";
  }
}

getPrviousStoragewithoutFunction();
for(let i = 0; i < addBtn.length; i++)
{
  addBtn[i].addEventListener("click", function() {
  if(inputText[i].value!= "") {
    if(i == 0) {
      myIU.push(inputText[i].value);
    }
    else if(i == 1) {
      myInotU.push(inputText[i].value);
    }
    else if(i == 2) {
      mynotIU.push(inputText[i].value);
    }
    else {
      mynotInotU.push(inputText[i].value);
    }
    inputText[i].value = "";
    if(i == 0) {
      localStorage.setItem(getArrayAsStrings(i), JSON.stringify(myIU));
      localStorage.setItem(getArrayCheckedAsStrings(i), JSON.stringify(myCheckedIU));
    }
    else if(i == 1) {
      localStorage.setItem(getArrayAsStrings(i), JSON.stringify(myInotU));
      localStorage.setItem(getArrayCheckedAsStrings(i), JSON.stringify(myCheckedInotU));
    }
    else if(i == 2) {
      localStorage.setItem(getArrayAsStrings(i), JSON.stringify(mynotIU));
      localStorage.setItem(getArrayCheckedAsStrings(i), JSON.stringify(myCheckednotIU));
    }
    else {
      localStorage.setItem(getArrayAsStrings(i), JSON.stringify(mynotInotU));
      localStorage.setItem(getArrayCheckedAsStrings(i), JSON.stringify(myCheckednotInotU));
    }

  }
  getPrviousStorage();
  });
}


function getPrviousStorage() {
  for(let i = 0; i < 4; i++)
  {
    let toDoList = "";
    let localStorageToDoList = JSON.parse(localStorage.getItem(getArrayAsStrings(i)));
    let checkedLocalStorageToDoList = JSON.parse(localStorage.getItem(getArrayCheckedAsStrings(i)));
    if(localStorageToDoList) {
      if(i == 0) {
        myIU = localStorageToDoList;
        toDoList += printToDoList(myIU);
      }
      else if(i == 1) {
        myInotU = localStorageToDoList;
        toDoList += printToDoList(myInotU);
      }
      else if(i == 2) {
        mynotIU = localStorageToDoList;
        toDoList += printToDoList(mynotIU);
      }
      else {
        mynotInotU = localStorageToDoList;
        toDoList += printToDoList(mynotInotU);
      }
    }
    if(checkedLocalStorageToDoList) {
      if(localStorageToDoList) {
        if(i == 0) {
          myCheckedIU = checkedLocalStorageToDoList;
          toDoList += printCheckedToDoList(myCheckedIU);
        }
        else if(i == 1) {
          myCheckedInotU = checkedLocalStorageToDoList;
          toDoList += printCheckedToDoList(myCheckedInotU);
        }
        else if(i == 2) {
          myCheckednotIU = checkedLocalStorageToDoList;
          toDoList += printCheckedToDoList(myCheckednotIU);
        }
        else {
          myCheckednotInotU = checkedLocalStorageToDoList;
          toDoList += printCheckedToDoList(myCheckednotInotU);
        }
    }
    ulList[i].innerHTML = toDoList;
  }
}
buttonFunctions();
}


function getPrviousStoragewithoutFunction() {
  for(let i = 0; i < 4; i++)
  {
    let toDoList = "";
    let localStorageToDoList = JSON.parse(localStorage.getItem(getArrayAsStrings(i)));
    let checkedLocalStorageToDoList = JSON.parse(localStorage.getItem(getArrayCheckedAsStrings(i)));
    if(localStorageToDoList) {
      if(i == 0) {
        myIU = localStorageToDoList;
        toDoList += printToDoList(myIU);
      }
      else if(i == 1) {
        myInotU = localStorageToDoList;
        toDoList += printToDoList(myInotU);
      }
      else if(i == 2) {
        mynotIU = localStorageToDoList;
        toDoList += printToDoList(mynotIU);
      }
      else {
        mynotInotU = localStorageToDoList;
        toDoList += printToDoList(mynotInotU);
      }
    }
    if(checkedLocalStorageToDoList) {
      if(localStorageToDoList) {
        if(i == 0) {
          myCheckedIU = checkedLocalStorageToDoList;
          toDoList += printCheckedToDoList(myCheckedIU);
        }
        else if(i == 1) {
          myCheckedInotU = checkedLocalStorageToDoList;
          toDoList += printCheckedToDoList(myCheckedInotU);
        }
        else if(i == 2) {
          myCheckednotIU = checkedLocalStorageToDoList;
          toDoList += printCheckedToDoList(myCheckednotIU);
        }
        else {
          myCheckednotInotU = checkedLocalStorageToDoList;
          toDoList += printCheckedToDoList(myCheckednotInotU);
        }
    }
    ulList[i].innerHTML = toDoList;
  }
}
}


function printToDoList(toDoListArray) {
  let toDoList = "";
  for(let toDos of toDoListArray) {
    toDoList +=  `<li id="list-Of-ToDo">
      <div id="input-label-Div">
        <input id="${toDos}" type="checkbox"/>
        <label for=${toDos} class="strikethrough">${toDos}</label>
      </div>
      <button id="delete-Btn"><i class="fa fa-trash-o"></i></button>
    </li>`;
  }
  return toDoList;
}

function printCheckedToDoList(checkedToDoListArray) {
  let toDoList = "";
  for(let toDos of checkedToDoListArray) {
    toDoList +=  `<li id="list-Of-ToDo">
      <div id="input-label-Div">
        <input id="${toDos}" type="checkbox" checked/>
        <label for=${toDos} class="strikethrough">${toDos}</label>
      </div>
      <button id="delete-Btn"><i class="fa fa-trash-o"></i></button>
    </li>`;
  }
  return toDoList;
}

function buttonFunctions() {
  let deleteTask = document.querySelectorAll('#delete-Btn');
  for(let i = 0; i < deleteTask.length; i++) {
    deleteTask[i].onclick = function() {
      let id = this.parentNode.parentNode.parentNode.id;
      if(id=="Important-Urgent") {
        if(myIU.includes(this.parentNode.textContent.split(" ").join("").split("\n").join(""))) {
          myIU.splice(myIU.indexOf(this.parentNode.textContent.split(" ").join("").split("\n").join("")), 1);
          localStorage.removeItem(getArrayAsStrings(0));
          localStorage.setItem(getArrayAsStrings(0), JSON.stringify(myIU));
        }
        else if(myCheckedIU.includes(this.parentNode.textContent.split(" ").join("").split("\n").join(""))) {
          myCheckedIU.splice(myCheckedIU.indexOf(this.parentNode.textContent.split(" ").join("").split("\n").join("")), 1);
          localStorage.removeItem(getArrayCheckedAsStrings(0));
          localStorage.setItem(getArrayCheckedAsStrings(0), JSON.stringify(myCheckedIU));
        }
      }
      else if(id=="Important-NotUrgent") {
        if(myInotU.includes(this.parentNode.textContent.split(" ").join("").split("\n").join(""))) {
          myInotU.splice(myInotU.indexOf(this.parentNode.textContent.split(" ").join("").split("\n").join("")), 1);
          localStorage.removeItem(getArrayAsStrings(1));
          localStorage.setItem(getArrayAsStrings(1), JSON.stringify(myInotU));
        }
        else if(myCheckedInotU.includes(this.parentNode.textContent.split(" ").join("").split("\n").join(""))) {
          myCheckedInotU.splice(myCheckedInotU.indexOf(this.parentNode.textContent.split(" ").join("").split("\n").join("")), 1);
          localStorage.removeItem(getArrayCheckedAsStrings(1));
          localStorage.setItem(getArrayCheckedAsStrings(1), JSON.stringify(myCheckedInotU));
        }
      }
      else if(id=="NotImportant-Urgent") {
        if(mynotIU.includes(this.parentNode.textContent.split(" ").join("").split("\n").join(""))) {
          mynotIU.splice(mynotIU.indexOf(this.parentNode.textContent.split(" ").join("").split("\n").join("")), 1);
          localStorage.removeItem(getArrayAsStrings(2));
          localStorage.setItem(getArrayAsStrings(2), JSON.stringify(mynotIU));
        }
        else if(myCheckednotIU.includes(this.parentNode.textContent.split(" ").join("").split("\n").join(""))) {
          myCheckednotIU.splice(myCheckednotIU.indexOf(this.parentNode.textContent.split(" ").join("").split("\n").join("")), 1);
          localStorage.removeItem(getArrayCheckedAsStrings(2));
          localStorage.setItem(getArrayCheckedAsStrings(2), JSON.stringify(myCheckednotIU));
        }
      }
      else {
        if(mynotInotU.includes(this.parentNode.textContent.split(" ").join("").split("\n").join(""))) {
          mynotInotU.splice(mynotInotU.indexOf(this.parentNode.textContent.split(" ").join("").split("\n").join("")), 1);
          localStorage.removeItem(getArrayAsStrings(3));
          localStorage.setItem(getArrayAsStrings(3), JSON.stringify(mynotInotU));
        }
        else if(myCheckednotInotU.includes(this.parentNode.textContent.split(" ").join("").split("\n").join(""))) {
          myCheckednotInotU.splice(myCheckednotInotU.indexOf(this.parentNode.textContent.split(" ").join("").split("\n").join("")), 1);
          localStorage.removeItem(getArrayCheckedAsStrings(3));
          localStorage.setItem(getArrayCheckedAsStrings(3), JSON.stringify(myCheckednotInotU));
        }
      }
      this.parentNode.remove();
      getPrviousStorage();
    }
  }


  let checkedTask = document.querySelectorAll('input[type="checkbox"]');
  for(let i = 0; i < checkedTask.length; i++) {
    checkedTask[i].addEventListener("change", function() {
      let id = this.parentNode.parentNode.parentNode.parentNode.id;
      if(id=="Important-Urgent") {
        if(myIU.includes(this.parentNode.parentNode.textContent.split(" ").join("").split("\n").join(""))) {
          let removeItem = myIU.splice(myIU.indexOf(this.parentNode.parentNode.textContent.split(" ").join("").split("\n").join("")), 1);
          localStorage.removeItem(getArrayAsStrings(0));
          localStorage.removeItem(getArrayCheckedAsStrings(0));
          myCheckedIU = myCheckedIU.concat(removeItem);
          localStorage.setItem(getArrayAsStrings(0), JSON.stringify(myIU));
          localStorage.setItem(getArrayCheckedAsStrings(0), JSON.stringify(myCheckedIU));
        }
        else if(myCheckedIU.includes(this.parentNode.parentNode.textContent.split(" ").join("").split("\n").join(""))) {
          let removeItem = myCheckedIU.splice(myCheckedIU.indexOf(this.parentNode.parentNode.textContent.split(" ").join("").split("\n").join("")), 1);
          localStorage.removeItem(getArrayAsStrings(0));
          localStorage.removeItem(getArrayCheckedAsStrings(0));
          myIU = myIU.concat(removeItem);
          localStorage.setItem(getArrayAsStrings(0), JSON.stringify(myIU));
          localStorage.setItem(getArrayCheckedAsStrings(0), JSON.stringify(myCheckedIU));
        }
        getPrviousStorage();
      }
      else if(id=="Important-NotUrgent") {
        if(myInotU.includes(this.parentNode.parentNode.textContent.split(" ").join("").split("\n").join(""))) {
          let removeItem = myInotU.splice(myInotU.indexOf(this.parentNode.parentNode.textContent.split(" ").join("").split("\n").join("")), 1);
          localStorage.removeItem(getArrayAsStrings(1));
          localStorage.removeItem(getArrayCheckedAsStrings(1));
          myCheckedInotU = myCheckedInotU.concat(removeItem);
          localStorage.setItem(getArrayAsStrings(1), JSON.stringify(myInotU));
          localStorage.setItem(getArrayCheckedAsStrings(1), JSON.stringify(myCheckedInotU));
        }
        else if(myCheckedInotU.includes(this.parentNode.parentNode.textContent.split(" ").join("").split("\n").join(""))) {
          let removeItem = myCheckedInotU.splice(myCheckedInotU.indexOf(this.parentNode.parentNode.textContent.split(" ").join("").split("\n").join("")), 1);
          localStorage.removeItem(getArrayAsStrings(1));
          localStorage.removeItem(getArrayCheckedAsStrings(1));
          myInotU = myInotU.concat(removeItem);
          localStorage.setItem(getArrayAsStrings(1), JSON.stringify(myInotU));
          localStorage.setItem(getArrayCheckedAsStrings(1), JSON.stringify(myCheckedInotU));
        }
        getPrviousStorage();
      }
      else if(id=="NotImportant-Urgent") {
        if(mynotIU.includes(this.parentNode.parentNode.textContent.split(" ").join("").split("\n").join(""))) {
          let removeItem = mynotIU.splice(mynotIU.indexOf(this.parentNode.parentNode.textContent.split(" ").join("").split("\n").join("")), 1);
          localStorage.removeItem(getArrayAsStrings(2));
          localStorage.removeItem(getArrayCheckedAsStrings(2));
          myCheckednotIU = myCheckednotIU.concat(removeItem);
          localStorage.setItem(getArrayAsStrings(2), JSON.stringify(mynotIU));
          localStorage.setItem(getArrayCheckedAsStrings(2), JSON.stringify(myCheckednotIU));
        }
        else if(myCheckednotIU.includes(this.parentNode.parentNode.textContent.split(" ").join("").split("\n").join(""))) {
          let removeItem = myCheckednotIU.splice(myCheckednotIU.indexOf(this.parentNode.parentNode.textContent.split(" ").join("").split("\n").join("")), 1);
          localStorage.removeItem(getArrayAsStrings(2));
          localStorage.removeItem(getArrayCheckedAsStrings(2));
          mynotIU = mynotIU.concat(removeItem);
          localStorage.setItem(getArrayAsStrings(2), JSON.stringify(mynotIU));
          localStorage.setItem(getArrayCheckedAsStrings(2), JSON.stringify(myCheckednotIU));
        }
        getPrviousStorage();
      }
      else {
        if(mynotInotU.includes(this.parentNode.parentNode.textContent.split(" ").join("").split("\n").join(""))) {
          let removeItem = mynotInotU.splice(mynotInotU.indexOf(this.parentNode.parentNode.textContent.split(" ").join("").split("\n").join("")), 1);
          localStorage.removeItem(getArrayAsStrings(3));
          localStorage.removeItem(getArrayCheckedAsStrings(3));
          myCheckednotInotU = myCheckednotInotU.concat(removeItem);
          localStorage.setItem(getArrayAsStrings(3), JSON.stringify(mynotInotU));
          localStorage.setItem(getArrayCheckedAsStrings(3), JSON.stringify(myCheckednotInotU));
        }
        else if(myCheckednotInotU.includes(this.parentNode.parentNode.textContent.split(" ").join("").split("\n").join(""))) {
          let removeItem = myCheckednotInotU.splice(myCheckednotInotU.indexOf(this.parentNode.parentNode.textContent.split(" ").join("").split("\n").join("")), 1);
          localStorage.removeItem(getArrayAsStrings(3));
          localStorage.removeItem(getArrayCheckedAsStrings(3));
          mynotInotU = mynotInotU.concat(removeItem);
          localStorage.setItem(getArrayAsStrings(3), JSON.stringify(mynotInotU));
          localStorage.setItem(getArrayCheckedAsStrings(3), JSON.stringify(myCheckednotInotU));
        }
        getPrviousStorage();
      }
    })
  }
}

buttonFunctions();
